use pdk::hl::{StreamProperties};
use pdk::hl::PropertyAccessor;
use hex;
use sha2::{Digest, Sha256};

pub fn read_property(stream: &StreamProperties, path: &[&str]) -> String {
    let bytes = stream.read_property(path).unwrap_or_default();
    String::from_utf8_lossy(&bytes).to_string()
}

pub fn hash_dns_value(dns_value: &str) -> String {
    let mut hasher = Sha256::new();
    hasher.update(dns_value);
    hex::encode(hasher.finalize())
}


#[cfg(test)]
mod tests {
    use super::*;
    use sha2::{Sha256, Digest};

    #[test]
    fn test_hash_dns_value_consistency() {
        let input = "example.com";
        let expected_hash = {
            let mut hasher = Sha256::new();
            hasher.update(input);
            hex::encode(hasher.finalize())
        };

        let actual_hash = hash_dns_value(input);
        assert_eq!(actual_hash, expected_hash);
    }

    #[test]
    fn test_hash_dns_value_empty_string() {
        let input = "";
        let expected_hash = {
            let mut hasher = Sha256::new();
            hasher.update(input);
            hex::encode(hasher.finalize())
        };

        let actual_hash = hash_dns_value(input);
        assert_eq!(actual_hash, expected_hash);
    }
    
}


