use crate::error_handling::{ErrorHandler, PolicyError};
use crate::subject_dn::parse_subject_dn;
use crate::utils::read_property;
use crate::utils::hash_dns_value;
use pdk::hl::*;
use pdk::logger;

pub async fn request_filter(request_state: RequestState, stream: StreamProperties) -> Flow<()> {
    let headers_state = request_state.into_headers_state().await;
    let headers_handler = headers_state.handler();

    let subject_str = read_property(&stream, &["connection", "subject_peer_certificate"]);

    match parse_subject_dn(&subject_str) {
        Err(err) => {
            let (status_code, _, body) = ErrorHandler::handle_error(
                PolicyError::Unauthorized(err.to_string()),
                "trace-id-placeholder".to_string(),
                "client-auth-policy".to_string(),
            );
            Flow::Break(Response::new(status_code).with_body(body))
        }
        Ok(_subject) => {
            let dns_value = read_property(&stream, &["connection", "dns_san_peer_certificate"]);
            logger::info!("Certificate content: {}", subject_str);

            let hex_str = hash_dns_value(&dns_value);
            headers_handler.set_header("client-id", &hex_str);
            logger::info!("Content of host_decoded: {}", hex_str);

            Flow::Continue(())
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_tc01_hash_generated_from_cn_only() {
        let input = "cn=client.bpi.co.id";
        let parsed = parse_subject_dn(input).unwrap();
        assert_eq!(parsed.common_name.len() > 0, true);
        let hash = hash_dns_value(&parsed.common_name);
        assert_eq!(hash.len(), 64);
    }

    #[test]
    fn test_tc02_hash_generated_from_cn_domain_style() {
        let input = "cn=apix.sandbox-111094.com";
        let parsed = parse_subject_dn(input).unwrap();
        assert_eq!(parsed.common_name.len() > 0, true);
        let hash = hash_dns_value(&parsed.common_name);
        assert_eq!(hash.len(), 64);
    }

    #[test]
    fn test_tc03_hash_includes_full_dn_structure() {
        let input = "cn=wrcwebdlf01.axa-id.intraxa,o=axa services indonesia,l=indonesia,st=indonesia,c=id";
        let parsed = parse_subject_dn(input).unwrap();
        assert_eq!(parsed.common_name.len() > 0, true);
        let hash = hash_dns_value(&parsed.common_name);
        assert_eq!(hash.len(), 64);
    }

    #[test]
    fn test_tc04_wildcard_cn_handled_correctly() {
        let input = "cn=*.axa.co.id,o=pt axa services indonesia,l=jakarta selatan,st=daerah khusus ibukota jakarta,c=id";
        let parsed = parse_subject_dn(input).unwrap();
        assert_eq!(parsed.common_name.len() > 0, true);
        let hash = hash_dns_value(&parsed.common_name);
        assert_eq!(hash.len(), 64);
    }

    #[test]
    fn test_tc05_hash_from_wildcard_cn_minimal_dn() {
        let input = "cn=*.sandbox-111094.com";
        let parsed = parse_subject_dn(input).unwrap();
        assert_eq!(parsed.common_name.len() > 0, true);
        let hash = hash_dns_value(&parsed.common_name);
        assert_eq!(hash.len(), 64);
    }

    #[test]
    fn test_tc06_email_field_and_full_dn_hashed() {
        let input = "1.2.840.113549.1.9.1=#1624...,cn=*.nprod.sg.corp.intraxa";
        let parsed = parse_subject_dn(input).unwrap();
        assert_eq!(parsed.common_name.len() > 0, true);
        let hash = hash_dns_value(&parsed.common_name);
        assert_eq!(hash.len(), 64);
    }

    #[test]
    fn test_tc07_case_insensitive_parsing() {
        let input = "CN=preprodesg.axa.co.id, O=PT Asuransi AXA Indonesia, L=JAKARTA, C=ID";
        let parsed = parse_subject_dn(input).unwrap();
        assert_eq!(parsed.common_name.len() > 0, true);
        let hash = hash_dns_value(&parsed.common_name);
        assert_eq!(hash.len(), 64);
    }

    #[test]
    fn test_tc08_long_cn_with_nested_ou() {
        let input = "cn=surrender-api.axa-li-jp-preprod-lpl-int,ou=api,ou=services,ou=axa,ou=jp";
        let parsed = parse_subject_dn(input).unwrap();
        assert_eq!(parsed.common_name.len() > 0, true);
        let hash = hash_dns_value(&parsed.common_name);
        assert_eq!(hash.len(), 64);
    }

    #[test]
    fn test_tc09_variation_in_cn_similar_to_tc08() {
        let input = "cn=psdept-preprod.surrender-api,ou=api,ou=services,ou=axa,ou=jp";
        let parsed = parse_subject_dn(input).unwrap();
        assert_eq!(parsed.common_name.len() > 0, true);
        let hash = hash_dns_value(&parsed.common_name);
        assert_eq!(hash.len(), 64);
    }

    #[test]
    fn test_tc10_oid_and_email_address_encoded_in_hex() {
        let input = "1.2.840.113549.1.9.1=#1618...,cn=api-np.int.krungthai-axa.co.th";
        let parsed = parse_subject_dn(input).unwrap();
        assert_eq!(parsed.common_name.len() > 0, true);
        let hash = hash_dns_value(&parsed.common_name);
        assert_eq!(hash.len(), 64);
    }

    #[test]
    fn test_tc11_short_cn_with_nested_ou() {
        let input = "cn=eip_stage,ou=infra,ou=platform";
        let parsed = parse_subject_dn(input).unwrap();
        assert_eq!(parsed.common_name.len() > 0, true);
        let hash = hash_dns_value(&parsed.common_name);
        assert_eq!(hash.len(), 64);
    }

    #[test]
    fn test_tc12_cn_with_ph_domain() {
        let input = "cn=sfdc-prod.axa.com.ph";
        let parsed = parse_subject_dn(input).unwrap();
        assert_eq!(parsed.common_name.len() > 0, true);
        let hash = hash_dns_value(&parsed.common_name);
        assert_eq!(hash.len(), 64);
    }

    #[test]
    fn test_tc13_very_long_cn_stress_test() {
        let input = "cn=claimsdatareg-preprod.claims-payment-input-hats-common-util-api";
        let parsed = parse_subject_dn(input).unwrap();
        assert_eq!(parsed.common_name.len() > 0, true);
        let hash = hash_dns_value(&parsed.common_name);
        assert_eq!(hash.len(), 64);
    }

    #[test]
    fn test_tc14_external_partner_hsbc_case() {
        let input = "cn=giil-filenet-hk,ou=hsbc";
        let parsed = parse_subject_dn(input).unwrap();
        assert_eq!(parsed.common_name.len() > 0, true);
        let hash = hash_dns_value(&parsed.common_name);
        assert_eq!(hash.len(), 64);
    }
    #[test]
    fn test_tc15_no_cn() {
        let input = "ou=hsbc";
        let parsed = parse_subject_dn(input);
        assert!(parsed.is_err());
        assert_eq!(parsed.unwrap_err().to_string(), "Common name missing from peer cert.");
    }

}
