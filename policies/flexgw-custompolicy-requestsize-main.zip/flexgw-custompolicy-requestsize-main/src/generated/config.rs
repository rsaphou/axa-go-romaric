use serde::Deserialize;
#[derive(Deserialize, Clone, Debug)]
pub struct Config {
    #[serde(alias = "max_payload_size_kb")]
    pub max_payload_size_kb: i64,
}
