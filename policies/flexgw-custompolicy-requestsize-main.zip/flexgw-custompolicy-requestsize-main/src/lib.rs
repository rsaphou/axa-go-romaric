// Copyright 2023 Salesforce, Inc. All rights reserved.
mod generated;
use anyhow::{anyhow, Result};

use pdk::hl::*;
use pdk::logger;

use generated::config::Config;


// This filter checks if the request payload is greater than the configured KB limit
// and logs a warning if it exceeds the limit
async fn request_filter(request_state: RequestState, config: &Config) -> Flow<()> {
    let headers_state = request_state.into_headers_state().await;

    let body_stream_state = headers_state.into_body_stream_state().await;
    let mut stream = body_stream_state.stream();

    let mut total_size = 0usize;
    let kb_max_size = config.max_payload_size_kb as f32 * 1000.0;

    while let Some(chunk) = stream.next().await {
        let chunk_bytes = chunk.into_bytes();
        let chunk_size = chunk_bytes.len();
        total_size += chunk_size;

        logger::debug!("Received chunk of {} bytes, total so far: {}", chunk_size, total_size);
        
        if (total_size as f32) > kb_max_size {
            logger::warn!("Request payload too large: {} kb (max: {} kb)", total_size as f32 / 1000.0, config.max_payload_size_kb);
            return Flow::Break(Response::new(413).with_body("Payload too large"));
        }
    }

    logger::debug!("Request payload Accepted: {} kb ", total_size as f32 / 1000.0);

    Flow::Continue(())
}


#[entrypoint]
async fn configure(launcher: Launcher, Configuration(bytes): Configuration) -> Result<()> {
    let config: Config = serde_json::from_slice(&bytes).map_err(|err| {
        anyhow!(
            "Failed to parse configuration '{}'. Cause: {}",
            String::from_utf8_lossy(&bytes),
            err
        )
    })?;
    let filter = on_request(|rs| request_filter(rs, &config));
    launcher.launch(filter).await?;
    Ok(())
}
